package com.zybooks.weighttrackingapp_zuha;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class AddGoalActivity extends AppCompatActivity {

    private TextInputEditText goalWeightEditText;
    private MaterialButton addButton;
    private ImageButton closeButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_goal);

        // Initialize our database engine
        dbHelper = new DatabaseHelper(this);

        // Link the UI elements from activity_goal.xml
        goalWeightEditText = findViewById(R.id.goalWeightEditText);
        addButton = findViewById(R.id.addGoalButton);
        closeButton = findViewById(R.id.closeButton);

        // Set click listener for the "Add" button
        addButton.setOnClickListener(v -> {
            String weightStr = Objects.requireNonNull(goalWeightEditText.getText()).toString().trim();

            // Check if the input is empty to prevent errors
            if (!weightStr.isEmpty()) {
                try {
                    float weightValue = Float.parseFloat(weightStr);

                    // Retrieve current user ID to know who is setting this goal so it goes to the right table row
                    SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                    int currentUserId = prefs.getInt("current_user_id", -1);

                    if (currentUserId != -1) {
                        // Save to the database using our relational helper method
                        dbHelper.setGoalWeight(currentUserId, weightValue);

                        Toast.makeText(this, "Goal updated successfully!", Toast.LENGTH_SHORT).show();
                        finish(); // Go back to MainActivity
                    } else {
                        Toast.makeText(this, "User error. Please log in again.", Toast.LENGTH_SHORT).show();
                    }

                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        // Set click listener for the "Close" button
        closeButton.setOnClickListener(v -> finish());
    }
}