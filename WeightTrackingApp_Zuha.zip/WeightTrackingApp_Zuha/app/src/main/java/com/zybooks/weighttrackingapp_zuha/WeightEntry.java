package com.zybooks.weighttrackingapp_zuha;

// Class that acts as a container to hold data for a single weight record
public class WeightEntry {

    // Variables to store the unique ID, the weight value, and the date from the database
    private int id;
    private float weight;
    private String date;

    // The constructor: used to fill this container with data when we create it
    public WeightEntry(int id, float weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    // Getter method to retrieve the unique database ID for this entry
    public int getId() { return id; }

    // Getter method to retrieve the weight value
    public float getWeight() { return weight; }

    // Getter method to retrieve the date string
    public String getDate() { return date; }
}