package com.zybooks.weighttrackingapp_zuha;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

// This class handles all communication between the app and the SQLite database
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database name and version
    private static final String DATABASE_NAME = "weightTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table names
    public static final String TABLE_USERS = "users";
    public static final String TABLE_WEIGHTS = "daily_weights";
    public static final String TABLE_GOAL = "goal_weight";

    // Standard columns used across tables
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USER_ID = "user_id"; // Links data to a specific user

    // Columns for the Users table
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Columns for the Daily Weights table
    public static final String COLUMN_WEIGHT_VALUE = "weight";
    public static final String COLUMN_DATE = "date";

    // Column for the Goal table
    public static final String COLUMN_GOAL_VALUE = "goal";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // This method runs the very first time the app is opened to build the database shell
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Build the table for user accounts
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT, " +
                COLUMN_PASSWORD + " TEXT)");

        // Build the table for weight entries, using user_id to keep data private to each user
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_ID + " INTEGER, " +
                COLUMN_WEIGHT_VALUE + " REAL, " +
                COLUMN_DATE + " TEXT)");

        // Build the table to store each user's specific weight goal
        db.execSQL("CREATE TABLE " + TABLE_GOAL + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USER_ID + " INTEGER, " +
                COLUMN_GOAL_VALUE + " REAL)");
    }

    // If we ever update the database structure, this clears the old data and starts fresh
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        onCreate(db);
    }

    //************************
    // --- LOGIN METHODS --- |
    //************************

    // Save a new user and return true if successful
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Check if a username is already taken
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=?", new String[]{username}, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        return exists;
    }

    // Get the User ID after checking if username and password match
    public int getUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);

        int id = -1; // -1 means user not found
        if (cursor.moveToFirst()) {
            id = cursor.getInt(0);
        }
        cursor.close();
        return id;
    }

    //****************************
    // --- ADD GOAL METHODS ---  |
    //****************************

    // Save or update the goal for a specific user
    public void setGoalWeight(int userId, float goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete any existing goal for this specific user first
        db.delete(TABLE_GOAL, COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)});

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_GOAL_VALUE, goal);
        db.insert(TABLE_GOAL, null, values);
    }

    // Fetch the goal for a specific user
    public float getGoalWeight(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_GOAL, new String[]{COLUMN_GOAL_VALUE},
                COLUMN_USER_ID + "=?", new String[]{String.valueOf(userId)}, null, null, null);

        float goal = 0;
        if (cursor.moveToFirst()) {
            goal = cursor.getFloat(0);
        }
        cursor.close();
        return goal;
    }

    //*************************************
    // --- ADD WEIGHT AND CRUD METHODS ---|
    //*************************************

    // CREATE: Add a new weight for a specific user
    public void addWeight(int userId, float weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_WEIGHT_VALUE, weight);
        values.put(COLUMN_DATE, date);
        db.insert(TABLE_WEIGHTS, null, values);
    }

    // READ: Get all weights for a specific user
    public List<WeightEntry> getAllWeights(int userId) {
        List<WeightEntry> weights = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Query the table and sort by ID so the newest entries appear first
        Cursor cursor = db.query(TABLE_WEIGHTS, null, COLUMN_USER_ID + "=?",
                new String[]{String.valueOf(userId)}, null, null, COLUMN_ID + " DESC");

        if (cursor.moveToFirst()) {
            do {
                // Pull data from the columns and add them to our list
                weights.add(new WeightEntry(
                        cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                        cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_WEIGHT_VALUE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_DATE))
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return weights;
    }

    // UPDATE: Change an existing weight value
    public void updateWeight(int id, float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT_VALUE, newWeight);

        // Finds the specific row by its unique ID and updates the weight column
        db.update(TABLE_WEIGHTS, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    // DELETE: Remove a weight entry
    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHTS, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }
}