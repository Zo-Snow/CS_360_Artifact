package com.zybooks.weighttrackingapp_zuha;

// Import statements for Android classes used in this activity
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

import android.content.SharedPreferences;
import android.widget.Toast;

import android.telephony.SmsManager;

public class AddWeightActivity extends AppCompatActivity {

    // Declare variables for UI elements
    private TextInputEditText weightEditText;
    private MaterialButton addButton;
    private ImageButton closeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        // Link UI elements in XML to the variables in this class
        weightEditText = findViewById(R.id.weightEditText);
        addButton = findViewById(R.id.addWeightButton);
        closeButton = findViewById(R.id.closeButton);

        // Add today's weight button
        addButton.setOnClickListener(v -> {

            String weightStr = Objects.requireNonNull(weightEditText.getText()).toString().trim();

            // Validate that the weight input is not empty
            if (!weightStr.isEmpty()) {
                float weightValue = Float.parseFloat(weightStr);

                // Retrieve the logged-in user's ID from SharedPreferences
                SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                int currentUserId = prefs.getInt("current_user_id", -1);

                // Get current date and create a formatted date string for the new entry
                String currentDate = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(new Date());

                // Save the new weight entry to the SQLite database
                DatabaseHelper dbHelper = new DatabaseHelper(this);
                dbHelper.addWeight(currentUserId, weightValue, currentDate);

                // Retrieve the user's goal weight to check for progress
                float goal = dbHelper.getGoalWeight(currentUserId);

                // Check if a goal exists and if the new weight is less than or equal to the goal
                if (goal > 0 && weightValue <= goal) {
                    // Check if we have permission to send SMS
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                            == PackageManager.PERMISSION_GRANTED) {

                        try {
                            // Mock phone number used for demonstration and testing purposes
                            String phoneNumber = "5551234567";
                            String message = "Congratulations! You've reached your weight goal of " + goal + " KG!";

                            // Use the system SMS manager to send the text notification
                            SmsManager smsManager = SmsManager.getDefault();
                            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

                            Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            // Handle cases where the SMS fails to send
                            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

                // Show success message and return to the previous screen
                Toast.makeText(this, "Weight added!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });

        // Close button
        closeButton.setOnClickListener(v -> finish());
    }
}
