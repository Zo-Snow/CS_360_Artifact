package com.zybooks.weighttrackingapp_zuha;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.android.material.button.MaterialButton;

// This activity allows the user to grant or deny permission for SMS notifications
public class SMSActivity extends AppCompatActivity {

    private MaterialButton toggleSmsButton;
    private TextView permissionStatusText;
    private ImageButton closeButton;

    // A unique ID used to track our specific request for SMS permission
    private static final int SMS_PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_activity);

        // Link the Java variables to the buttons and text in the XML layout
        toggleSmsButton = findViewById(R.id.toggleSmsButton);
        permissionStatusText = findViewById(R.id.permissionStatusText);
        closeButton = findViewById(R.id.closeButton);

        // Check the current status immediately when the screen opens
        updateUI();

        // Close this screen and go back to the main dashboard
        closeButton.setOnClickListener(v -> finish());

        // When clicked, button asks the Android system to show the permission popup
        toggleSmsButton.setOnClickListener(v -> {
            // Only ask for permission if user does not already have it
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                // Trigger the standard Android "Allow/Deny" popup
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_REQUEST_CODE);
            }
        });
    }

    // Change the text and colors based on whether permission is granted
    private void updateUI() {
        // Ask the system if we currently have permission to send SMS
        boolean hasPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (hasPermission) {
            // If yes, show a green checkmark and disable the button since it is already done
            permissionStatusText.setText("✅ Permissions Granted");
            permissionStatusText.setTextColor(getResources().getColor(R.color.green));

            toggleSmsButton.setText("Notifications Enabled");
            toggleSmsButton.setEnabled(false); // Stop the user from clicking it again
            toggleSmsButton.setAlpha(0.6f);    // Make the button look slightly faded
        } else {
            // If no, show a red X and keep the button active so they can enable it
            permissionStatusText.setText("❌ Permissions Not Granted");
            permissionStatusText.setTextColor(getResources().getColor(R.color.red));

            toggleSmsButton.setText("Enable Notifications");
            toggleSmsButton.setEnabled(true);
            toggleSmsButton.setAlpha(1.0f);
        }
    }

    // Ensure the screen updates if the user changes settings and returns to the app
    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }

    // Method runs automatically after the user clicks "Allow" or "Deny" on the popup
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Check if this result is for our specific SMS request
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            // If the array has a result and it equals 'GRANTED'
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Notifications Enabled!", Toast.LENGTH_SHORT).show();
            } else {
                // Inform the user that they will miss out on alerts if they deny permission
                Toast.makeText(this, "Permission denied. You won't receive goal alerts.", Toast.LENGTH_LONG).show();
            }

            // Refresh the text and buttons to reflect the user's choice
            updateUI();
        }
    }
}