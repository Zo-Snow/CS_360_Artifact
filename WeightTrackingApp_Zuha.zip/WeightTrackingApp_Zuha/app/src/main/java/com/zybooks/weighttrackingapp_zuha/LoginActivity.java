package com.zybooks.weighttrackingapp_zuha;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import java.util.Objects;


// This class handles user authentication, session persistence,
// and creating new user accounts in the database
public class LoginActivity extends AppCompatActivity {

    // UI elements for user input
    private TextInputEditText usernameEditText;
    private TextInputEditText passwordEditText;

    private Button loginButton;

    private Button createAccountButton;

    // Database tool to handle user data
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Check if a User ID is already saved in the phone's memory (SharedPreferences)
        // If it is, we skip the login screen and go straight to the main app
        int savedUserId = getSharedPreferences("UserPrefs", MODE_PRIVATE)
                .getInt("current_user_id", -1);

        if (savedUserId != -1) {
            navigateToMainActivity();
            return; // Exit this method so the login screen doesn't load
        }

        // If no user is saved, we load the login layout and link the UI components.
        setContentView(R.layout.activity_login);
        dbHelper = new DatabaseHelper(this);
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);

        // Checks the database to see if the username and password match a record
        loginButton.setOnClickListener(v -> {
            // Objects.requireNonNull prevents a NullPointerException if the input field is missing
            // .toString() converts the input to text, and .trim() removes accidental leading/trailing spaces
            String username = Objects.requireNonNull(usernameEditText.getText()).toString().trim();
            String password = Objects.requireNonNull(passwordEditText.getText()).toString().trim();

            // Ask the user to enter all fields if any of them is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show();
                return;
            }

            // Ask the database for the user's unique ID based on their login info
            int userId = dbHelper.getUserId(username, password);

            if (userId != -1) {
                // If success, save the session and move to the next screen
                saveUserSession(userId, username);
                navigateToMainActivity();
            } else {
                // If fails, notify the user of incorrect credentials
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        });

        // Checks if the username is taken. If not, adds a new user to the database
        createAccountButton.setOnClickListener(v -> {
            String username = Objects.requireNonNull(usernameEditText.getText()).toString().trim();
            String password = Objects.requireNonNull(passwordEditText.getText()).toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the username is already in the database
            if (dbHelper.checkUsernameExists(username)) {
                // If password and username both already exist, log in the user instead
                int existingUserId = dbHelper.getUserId(username, password);
                if (existingUserId != -1) {
                    Toast.makeText(this, "Account already exists. Logging you in...", Toast.LENGTH_SHORT).show();
                    saveUserSession(existingUserId, username);
                    navigateToMainActivity();
                } else {
                    // If username exists but password is wrong, they must choose a new name
                    Toast.makeText(this, "Username exists already, kindly choose another username", Toast.LENGTH_LONG).show();
                }
                return;
            }

            // Call the database helper to insert the new user record to the DB
            boolean success = dbHelper.addUser(username, password);
            if (success) {
                // Retrieve the new ID and save the session
                int newUserId = dbHelper.getUserId(username, password);
                saveUserSession(newUserId, username);
                Toast.makeText(this, "Account Created!", Toast.LENGTH_SHORT).show();
                navigateToMainActivity();
            } else {
                Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Helper method to save the user's data locally on the phone
    // This keeps the user logged in even if they close the app
    private void saveUserSession(int userId, String username) {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("current_user_id", userId);
        editor.putString("current_username", username);
        editor.apply(); // Finalize the save
    }

    // Helper method to switch from Login screen to the Main screen.
    private void navigateToMainActivity() {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish(); // Remove the login screen from the back-stack
    }
}