package com.zybooks.weighttrackingapp_zuha;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // UI components
    private MaterialButton logoutButton;
    private ImageButton notificationSettingsButton;
    private MaterialButton addTodaysWeightButton;
    private MaterialButton addChangeGoalButton;
    private RecyclerView dailyWeightsRecyclerView;
    private TextView greetingText;
    private TextView goalWeightValue;

    // Database and User Info
    private DatabaseHelper dbHelper;
    private int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Database Helper
        dbHelper = new DatabaseHelper(this);

        // Retrieve user session
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        currentUserId = prefs.getInt("current_user_id", -1);
        String username = prefs.getString("current_username", "User");

        // Link UI components
        logoutButton = findViewById(R.id.logoutButton);
        notificationSettingsButton = findViewById(R.id.notificationSettingsButton);
        addTodaysWeightButton = findViewById(R.id.addTodaysWeightButton);
        addChangeGoalButton = findViewById(R.id.addChangeGoalButton);
        dailyWeightsRecyclerView = findViewById(R.id.dailyWeightsRecyclerView);
        greetingText = findViewById(R.id.greetingText);
        goalWeightValue = findViewById(R.id.goalWeightValue);

        // Set personalized greeting
        greetingText.setText("Hello " + username + "!");

        // Set up RecyclerView
        setupRecyclerView();

        // Clear session and go back to login page
        logoutButton.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear(); // This removes the saved User ID and Name
            editor.apply();

            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        // Open SMS Notification Settings
        notificationSettingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SMSActivity.class);
            startActivity(intent);
        });

        // Open Add Weight Screen
        addTodaysWeightButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddWeightActivity.class);
            startActivity(intent);
        });

        // Open Add/Change Goal Screen
        addChangeGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddGoalActivity.class);
            startActivity(intent);
        });
    }

    // Method runs every time user returns to this screen
    @Override
    protected void onResume() {
        super.onResume();
        refreshGoalDisplay(); // Refresh the goal weight after adding/changing goal weight
        setupRecyclerView(); // Refresh the grid after adding a weight
    }

    // Fetches the goal weight from the DB for the current user only
    private void refreshGoalDisplay() {
        float goal = dbHelper.getGoalWeight(currentUserId);
        if (goal > 0) {
            goalWeightValue.setText(goal + " KG");
        } else {
            goalWeightValue.setText("Not Set");
        }
    }

     // This method fetches all weight records for the current user and
     // organizes them into a 2-column grid layout
    public void setupRecyclerView() {
        // Fetch the list of weights from the database for the specific user
        List<WeightEntry> realWeights = dbHelper.getAllWeights(currentUserId);

        // Initialize the adapter which bridges the data to the UI
        DailyWeightsAdapter adapter = new DailyWeightsAdapter(realWeights, dbHelper);

        // Use GridLayoutManager to satisfy the 'Grid' display requirement (2 columns)
        dailyWeightsRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Attach the adapter to the RecyclerView to render the list
        dailyWeightsRecyclerView.setAdapter(adapter);
    }
}