package com.zybooks.weighttrackingapp_zuha;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

// This adapter connects the list of weights from the database to the individual items in the grid
public class DailyWeightsAdapter extends RecyclerView.Adapter<DailyWeightsAdapter.DailyWeightViewHolder> {

    private List<WeightEntry> weightList;
    private DatabaseHelper dbHelper;

    // Constructor: Takes the list of data and the database tool so it can handle edits/deletes
    public DailyWeightsAdapter(List<WeightEntry> weightList, DatabaseHelper dbHelper) {
        this.weightList = weightList;
        this.dbHelper = dbHelper;
    }

    // Method creates the visual card for each weight entry
    @NonNull
    @Override
    public DailyWeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item_daily_weight XML layout into a real view
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_daily_weight, parent, false);
        return new DailyWeightViewHolder(view);
    }

    // Method fills each card with the correct date and weight info
    @Override
    public void onBindViewHolder(@NonNull DailyWeightViewHolder holder, int position) {
        // Get the specific weight entry for this position in the list
        WeightEntry entry = weightList.get(position);

        // Display the date and weight
        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(entry.getWeight() + " KG");

        // When the trash icon is clicked, remove the data
        holder.deleteButton.setOnClickListener(v -> {
            // Remove it from the SQLite database permanently
            dbHelper.deleteWeight(entry.getId());

            // Remove it from the current list in the app's memory
            weightList.remove(position);

            // Tell the grid to refresh so the item disappears with an animation
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, weightList.size());
        });

        // When the edit icon is clicked, open a popup to change the weight
        holder.editButton.setOnClickListener(v -> {
            // Create an Alert Dialog (popup)
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(v.getContext());
            builder.setTitle("Update Weight");

            // Set up a text box in the popup for the user to type in
            final android.widget.EditText input = new android.widget.EditText(v.getContext());
            // Ensure the user can enter decimal numbers
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setText(String.valueOf(entry.getWeight())); // Show the old weight first
            builder.setView(input);

            // If the user clicks "Update"
            builder.setPositiveButton("Update", (dialog, which) -> {
                String newVal = input.getText().toString();
                if (!newVal.isEmpty()) {
                    float updatedWeight = Float.parseFloat(newVal);

                    // Save the new weight value to the database
                    dbHelper.updateWeight(entry.getId(), updatedWeight);

                    // Refresh the whole grid on the Main screen to show the update
                    ((MainActivity)v.getContext()).setupRecyclerView();
                }
            });

            // If they click cancel, just close the popup
            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });
    }

    // Tells the app how many items are in the list
    @Override
    public int getItemCount() { return weightList.size(); }

    // Class that holds the references to the text and buttons inside each card
    public static class DailyWeightViewHolder extends RecyclerView.ViewHolder {
        public TextView dateText, weightText;
        public ImageButton deleteButton, editButton;

        public DailyWeightViewHolder(View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            weightText = itemView.findViewById(R.id.weightText);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editButton = itemView.findViewById(R.id.editButton);
        }
    }
}